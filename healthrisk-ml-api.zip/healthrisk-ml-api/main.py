"""HealthRisk AI prediction service (FastAPI).
Educational/research use only - not medical diagnosis.
Endpoints: GET /health, POST /api/predict (matches the HealthRisk AI app)."""
import json, math, os
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

BUNDLE = json.loads((Path(__file__).parent / "models.json").read_text())
MODELS = {m["name"]: m for m in BUNDLE["models"]}
VERSION = BUNDLE["version"]

app = FastAPI(title="HealthRisk AI ML API", version=VERSION)
origins = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "*").split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST"], allow_headers=["*"])

class PredictionRequest(BaseModel):
    age: float = Field(ge=18, le=110)
    gender: str
    bmi: float = Field(gt=10, lt=80)
    blood_pressure: str  # "120/80"
    heart_rate: float = Field(ge=30, le=220)
    glucose: float = Field(ge=40, le=600)
    cholesterol: float = Field(ge=80, le=500)
    exercise_level: str
    smoking_status: str
    sleep_hours: float = Field(ge=0, le=24)
    family_history: bool
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None
    alcohol_frequency: Optional[str] = None
    previous_conditions: Optional[List[str]] = None

def level(p: float) -> str:
    return "high" if p >= 20 else "moderate" if p >= 7.5 else "low"

def run(name: str, x: dict) -> float:
    m = MODELS[name]
    z = m["intercept"]
    for f, w, mu, sd in zip(m["features"], m["weights"], m["mean"], m["std"]):
        z += w * ((x[f] - mu) / sd)
    return round(100 / (1 + math.exp(-z)), 1)

def hypertension(age, sbp, dbp, bmi, smoker, fam):
    # Simplified points index (research only)
    s = (age >= 45) * 15 + (sbp >= 130) * 25 + (sbp >= 140) * 15 + (dbp >= 85) * 10 + (bmi >= 30) * 15 + smoker * 10 + fam * 10
    return float(min(s, 95))

@app.get("/health")
def health():
    return {"status": "ok", "model_version": VERSION, "models": list(MODELS)}

@app.post("/api/predict")
def predict(r: PredictionRequest):
    try:
        sbp, dbp = (float(v) for v in r.blood_pressure.split("/"))
    except Exception:
        raise HTTPException(422, "blood_pressure must look like 120/80")
    male = 1.0 if r.gender.lower().startswith("m") else 0.0
    smoker = r.smoking_status.lower() in ("current", "smoker", "yes")
    heart = run("Cardiovascular disease", {"age": r.age, "sex": male, "trestbps": sbp, "chol": r.cholesterol, "fbs": 1.0 if r.glucose > 120 else 0.0})
    diab = run("Type 2 diabetes", {"age": r.age, "bmi": r.bmi, "glucose": r.glucose, "dbp": dbp})
    hyp = hypertension(r.age, sbp, dbp, r.bmi, smoker, r.family_history)
    diseases = [
        {"disease": "Heart Disease", "risk_percentage": heart, "risk_level": level(heart), "model_name": f"{VERSION} (UCI Cleveland)"},
        {"disease": "Diabetes", "risk_percentage": diab, "risk_level": level(diab), "model_name": f"{VERSION} (Pima)"},
        {"disease": "Hypertension", "risk_percentage": hyp, "risk_level": level(hyp), "model_name": "points-index-v1"},
    ]
    overall = max(d["risk_percentage"] for d in diseases)
    return {"overall_risk": overall, "risk_level": level(overall), "diseases": diseases,
            "model_name": VERSION, "prediction_timestamp": datetime.now(timezone.utc).isoformat()}
