# HealthRisk AI - ML prediction service
Educational/research use only. Not medical diagnosis.

## Run locally
pip install -r requirements.txt
uvicorn main:app --reload        # http://localhost:8000/health

## Deploy on Render (free)
1. Push this folder to a GitHub repo.
2. Render -> New -> Web Service -> pick the repo.
3. Build: `pip install -r requirements.txt`  Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Optional env var ALLOWED_ORIGINS=https://risk-compass-io.lovable.app
5. Copy the service URL and send it to Lovable.

Works the same on Railway, Fly.io, or Hugging Face Spaces (Docker) using the Dockerfile.

## API
GET  /health
POST /api/predict  {age, gender, bmi, blood_pressure:"120/80", heart_rate, glucose,
                    cholesterol, exercise_level, smoking_status, sleep_hours, family_history}
